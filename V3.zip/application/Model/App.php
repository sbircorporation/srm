<?php

namespace Mini\Model; 
use Mini\Core\Model;

class App extends Model
{
    // uid each time
    public function generateUniqueId($table) {
        do {
            $uniqueId = bin2hex(random_bytes(8));  
            $checkSql = "SELECT COUNT(*) FROM {$table} WHERE id = :id";
            $checkQuery = $this->db->prepare($checkSql);
            $checkQuery->bindParam(':id', $uniqueId, \PDO::PARAM_STR);
            $checkQuery->execute();
            $count = $checkQuery->fetchColumn();
        } while ($count > 0);
        return $uniqueId;
    }
    // loggs
    public function insert_loggs($table, $action, $message, $type,$datenow,$userid, $sessionid,$url,$uri,$suburl,$version,$lang,$project) {
        $uniqueId = $this->generateUniqueId($table);
        $sql = "INSERT INTO {$table} (id, deleted, status, action, message, type,created_at, modified_at, userid, sessionid,url,uri,suburl,version,lang,project) VALUES (:id, '0', '1', :action, :message, :type, :datenow, :datenow, :userid, :sessionid,:url,:uri,:suburl,:version,:lang,:project)";
        $query = $this->db->prepare($sql);
        $query->bindParam(':datenow', $datenow, \PDO::PARAM_STR);
        $query->bindParam(':id', $uniqueId, \PDO::PARAM_STR);
        $query->bindParam(':action', $action, \PDO::PARAM_STR);
        $query->bindParam(':message', $message, \PDO::PARAM_STR);
        $query->bindParam(':type', $type, \PDO::PARAM_STR);
        $query->bindParam(':userid', $userid, \PDO::PARAM_STR);
        $query->bindParam(':sessionid', $sessionid, \PDO::PARAM_STR);

        $query->bindParam(':url', $url, \PDO::PARAM_STR);
        $query->bindParam(':uri', $uri, \PDO::PARAM_STR);
        $query->bindParam(':suburl', $suburl, \PDO::PARAM_STR);
        $query->bindParam(':version', $version, \PDO::PARAM_STR);
        $query->bindParam(':lang', $lang, \PDO::PARAM_STR);
        $query->bindParam(':project', $project, \PDO::PARAM_STR);

        $query->execute();
        //return $uniqueId;
    }
   
      
    public function new_session($prefix,$userid,$api_ipgeolocation) {
        $ipAddress = $this->getUserIP(); 
        $userAgent = $_SERVER['HTTP_USER_AGENT']; 
        $phpInfo = [
            'PHP Version' => phpversion(),
            'Server Software' => $_SERVER['SERVER_SOFTWARE'],
            'Server Protocol' => $_SERVER['SERVER_PROTOCOL'],
        ]; 
        $locationInfo = $this->getGeoLocation($prefix,$userid,$ipAddress,$api_ipgeolocation); 
        $_SESSION['session_details'] = [
            'IP Address' => $ipAddress,
            'User Agent' => $userAgent,
            'PHP Info' => $phpInfo,
            'Location Info' => $locationInfo
        ];

        return $_SESSION['session_details'];
    }

private function getUserIP() {
    $ipKeys = [
        'HTTP_CLIENT_IP', 
        'HTTP_X_FORWARDED_FOR', 
        'HTTP_X_FORWARDED', 
        'HTTP_X_CLUSTER_CLIENT_IP', 
        'HTTP_FORWARDED_FOR', 
        'HTTP_FORWARDED', 
        'REMOTE_ADDR'
    ];
    foreach ($ipKeys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
    }
    return 'NA';
}

private function makeApiCall($url) {
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    curl_setopt($ch, CURLOPT_HEADER, false); 
    $response = curl_exec($ch); 
    curl_close($ch); 
    return json_decode($response, true); 
}


private function check_status_api_location($prefix,$type) { $results = 0;
            $table = $prefix . "system";
            $sql = "SELECT * FROM " . $table . " WHERE name = 'SYS' ";
            $query = $this->db->prepare($sql); 
            $query->execute();
            $fordb =  $query->fetchAll();
            foreach ($fordb as $info) {  
                if($type=="ipapi") {
                    $results =  $this->html($info->case_ipapi); 
                } else if($type == "ipinfo") {
                    $results =  $this->html($info->case_ipinfo); 
                } 
            } 
            return $results; 
}

private function getGeoLocation($prefix,$userid,$ip,$api_ipgeolocation) {
    $case_ipapi = $this->check_status_api_location($prefix,'ipapi');
    $case_ipinfo = $this->check_status_api_location($prefix,'ipinfo');
    
    if($case_ipapi == "1") {
        $url = "http://ip-api.com/json/$ip";
        $data = $this->makeApiCall($url);
        if ($this->isValidData($data)) {
            return $this->formatGeoData($data);
        }
    }

    if($case_ipinfo == "1") {
        $url = "https://ipinfo.io/$ip/json";
        $data = $this->makeApiCall($url);
        if ($this->isValidData($data, 'ipinfo')) {
            return $this->formatGeoData($data, 'ipinfo');
        }
    }
 


     if( $api_ipgeolocation == "1") {
        $url = "https://api.ipgeolocation.io/ipgeo?apiKey=$api_ipgeolocation&ip=$ip";
        $data = $this->makeApiCall($url);

        if ($this->isValidData($data, 'ipgeolocation')) {
            return $this->formatGeoData($data, 'ipgeolocation');
        }
    }

    return [
        'Country' => 'NA',
        'Region' => 'NA',
        'City' => 'NA',
        'Latitude' => 'NA',
        'Longitude' => 'NA'
    ];
}

private function isValidData($data, $api = '') {
    switch ($api) {
        case 'ipgeolocation':
            return isset($data['country_name'], $data['latitude'], $data['longitude']);
        case 'ipinfo':
            return isset($data['country'], $data['loc']);
        default: 
            return isset($data['country'], $data['region'], $data['city'], $data['lat'], $data['lon']);
    }
}

private function formatGeoData($data, $api = '') {
    $result = [
        'Country' => $data['country'] ?? 'NA',
        'Region' => $data['region'] ?? 'NA',
        'City' => $data['city'] ?? 'NA',
        'Latitude' => $data['lat'] ?? 'NA',
        'Longitude' => $data['lon'] ?? 'NA',
        'TLDs' => $data['tlds'] ?? 'NA',
        'Time Zones' => $data['time_zone'] ?? 'NA',
        'Language' => $data['language'] ?? 'NA',
        'Currency Code' => $data['currency_code'] ?? 'NA',
        'Currency Name' => $data['currency_name'] ?? 'NA',
        'Continent Code' => $data['continent_code'] ?? 'NA',
        'Is Proxy' => $data['is_proxy'] ?? 'NA',
        'Zip Code' => $data['zip_code'] ?? 'NA',
        'TimeZone' => $data['time_zone'] ?? 'NA'
    ];

    switch ($api) {
        case 'ipinfo':
            $location = explode(',', $data['loc'] ?? '');
            $result['Latitude'] = $location[0] ?? 'NA';
            $result['Longitude'] = $location[1] ?? 'NA';
            break;
        case 'ipgeolocation':
            $result['Latitude'] = $data['latitude'] ?? 'NA';
            $result['Longitude'] = $data['longitude'] ?? 'NA';
            $result['Country'] = $data['country_name'] ?? 'NA';
            $result['Continent'] = $data['continent_name'] ?? 'NA';
            $result['Country Code'] = $data['country_code2'] ?? 'NA';
            $result['Country Official'] = $data['country_name_official'] ?? 'NA';
            $result['Capital'] = $data['country_capital'] ?? 'NA';
            break;
        default:
            $result['Latitude'] = $data['lat'] ?? 'NA';
            $result['Longitude'] = $data['lon'] ?? 'NA';
            break;
    }
 

    return $result;
}

    
    
    
    
    
    
// SELECT GLOBAL
    public function get_config($table, $row,$id,$prefix,$datenow,$url,$uri,$suburl,$version,$lang,$project)
    {    
        $table = $prefix . $table;
        $table_loggs = $prefix . "loggs";
        
         $allowedTables = [$prefix . "config", $prefix . "system"];
        if (!in_array($table, $allowedTables)) {
            $message_log = 'Invalid table name.';
            throw new \Exception($message_log);
            $this->insert_loggs($table_loggs, 'VIEW',$message_log,'SYSTEM',$datenow,'','',$url,$uri,$suburl,$version,$lang,$project);
        } 
 
            $sql = "SELECT * FROM " . $table . " WHERE :row = :id";
            $query = $this->db->prepare($sql);
            $query->bindParam(':id', $id);
            $query->bindParam(':row', $row, \PDO::PARAM_STR);
            $query->execute();
            $result =  $this->counting($table, $row, $id,'0','1');
            if($result==0) {
                $this->action_config($table,'DELETE', '', '','','',$datenow,'','');
                $this->action_config($table,'INSERT', $row, $id,'0','1',$datenow,'','');
                $this->action_config($table,'UPDATE', $row, $id,'0','1',$datenow,'case_session','1');
                $this->action_config($table,'UPDATE', $row, $id,'0','1',$datenow,'case_loggs','1');
                $this->insert_loggs($table_loggs, 'INSERT','CONFIGURATION SYSTEM','SYSTEM',$datenow,'','',$url,$uri,$suburl,$version,$lang,$project);
                header("Refresh:0");  
               exit();
            } else {
                //return $query->fetchAll();
                //return $query->fetchAll(PDO::FETCH_ASSOC);
            }
          
    }
    // COUNT GLOBAL
       public function counting($table, $row, $id,$deleted,$status)  
       {
           $sql = "SELECT COUNT($row) AS amounts FROM {$table} where deleted = :deleted and status = :status ";
           $query = $this->db->prepare($sql);
           $query->bindParam(':deleted', $deleted, \PDO::PARAM_INT );
           $query->bindParam(':status', $status, \PDO::PARAM_INT );
           $query->execute(); 
           return $query->fetch()->amounts;
       }

    //  GLOBAL ACTION
     public function action_config($table,$action, $row, $id,$deleted,$status,$datenow,$fromto,$toto) { 
        if($action == "DELETE") {
            if(!empty($row)) {
                $sql = "DELETE FROM {$table} WHERE {$row} = :id ";
                $query = $this->db->prepare($sql);
                $query->bindParam(':id', $id );
                $query->execute();
            } else {
                $sql = "DELETE FROM {$table} WHERE 1 ";
                $query = $this->db->prepare($sql);
                $query->execute();
            } 
        } else if($action == "UPDATE") {
            if(!empty($row)) {
                $sql = "UPDATE {$table} set {$fromto}=:toto WHERE {$row} = :id ";
                $query = $this->db->prepare($sql);
                $query->bindParam(':id', $id );
                $query->bindParam(':toto', $toto );
                $query->execute();
            } 
        } else if($action == "INSERT") {
            $sql = "INSERT INTO {$table} ({$row},deleted,status,created_at, modified_at) VALUES (:id,:deleted,:status,:datenow,:datenow)";
            $query = $this->db->prepare($sql);
            $query->bindParam(':id', $id );
            $query->bindParam(':datenow', $datenow, \PDO::PARAM_STR  );
            $query->bindParam(':deleted', $deleted, \PDO::PARAM_INT );
            $query->bindParam(':status', $status, \PDO::PARAM_INT );
            $query->execute();
        }
        return 0;
    }
    
    public function html($data)
    {
        return htmlentities($data, ENT_QUOTES, 'UTF-8');
    }
 
    // INSERT session
    public function add_active_session($prefix, $url,$uri,$version,$userid, $datenow, $user_ip, $user_agent, $php_version, $server_software, $server_protocol, $country, $region, $city, $longitude, $latitude, $continent, $countryCode, $countryOfficial, $capital, $tlds, $timeZones, $language, $currencyCode, $currencyName, $continentCode, $isProxy, $zipCode, $timeZone,$browserType,$screenWidth,$screenHeight,$deviceType,$deviceId,$deviceReference) {
        $table = $prefix . "sessions";
        $deleted = 0;$status = 1;if(empty($browserType)) { $browserType = 'NA'; }if(empty($screenWidth)) { $screenWidth = 'NA'; }if(empty($screenHeight)) { $screenHeight = 'NA'; }if(empty($deviceType)) { $deviceType = 'NA'; }if(empty($deviceId)) { $deviceId = 'NA'; }if(empty($deviceReference)) { $deviceReference = 'NA'; }
        $uniqueId = $this->generateUniqueId($table);
    
        $sql = "INSERT INTO {$table} (id, url, uri, version, userid, deleted, status, created_at, modified_at, user_agent, php_version, server_software, server_protocol, country, region, city, longitude, latitude, continent, country_code, country_official, capital, tlds, time_zones, lang, currency_code, currency_name, continent_code, is_proxy, zip_code, time_zone,browserType,screenWidth,screenHeight,deviceType,deviceId,deviceReference)
                VALUES (:id, :url, :uri, :version, :userid, :deleted, :status, :created_at, :modified_at, :user_agent, :php_version, :server_software, :server_protocol, :country, :region, :city, :longitude, :latitude, :continent, :countryCode, :countryOfficial, :capital, :tlds, :timeZones, :language, :currencyCode, :currencyName, :continentCode, :isProxy, :zipCode, :timeZone,:browserType,:screenWidth,:screenHeight,:deviceType,:deviceId,:deviceReference)";
    
        $query = $this->db->prepare($sql);
    
        $query->bindParam(':id', $uniqueId, \PDO::PARAM_STR);
        $query->bindParam(':url', $url, \PDO::PARAM_STR);
        $query->bindParam(':uri', $uri, \PDO::PARAM_STR );
        $query->bindParam(':version', $version, \PDO::PARAM_STR );
        $query->bindParam(':userid', $userid, \PDO::PARAM_INT);
        $query->bindParam(':deleted', $deleted, \PDO::PARAM_INT);
        $query->bindParam(':status', $status, \PDO::PARAM_INT);
        $query->bindParam(':created_at', $datenow, \PDO::PARAM_STR);
        $query->bindParam(':modified_at', $datenow, \PDO::PARAM_STR);
        $query->bindParam(':user_agent', $user_agent, \PDO::PARAM_STR);
        $query->bindParam(':php_version', $php_version, \PDO::PARAM_STR);
        $query->bindParam(':server_software', $server_software, \PDO::PARAM_STR);
        $query->bindParam(':server_protocol', $server_protocol, \PDO::PARAM_STR);
        $query->bindParam(':country', $country, \PDO::PARAM_STR);
        $query->bindParam(':region', $region, \PDO::PARAM_STR);
        $query->bindParam(':city', $city, \PDO::PARAM_STR);
        $query->bindParam(':longitude', $longitude, \PDO::PARAM_STR);
        $query->bindParam(':latitude', $latitude, \PDO::PARAM_STR);
        $query->bindParam(':continent', $continent, \PDO::PARAM_STR);
        $query->bindParam(':countryCode', $countryCode, \PDO::PARAM_STR);
        $query->bindParam(':countryOfficial', $countryOfficial, \PDO::PARAM_STR);
        $query->bindParam(':capital', $capital, \PDO::PARAM_STR);
        $query->bindParam(':tlds', $tlds, \PDO::PARAM_STR);
        $query->bindParam(':timeZones', $timeZones, \PDO::PARAM_STR);
        $query->bindParam(':language', $language, \PDO::PARAM_STR);
        $query->bindParam(':currencyCode', $currencyCode, \PDO::PARAM_STR);
        $query->bindParam(':currencyName', $currencyName, \PDO::PARAM_STR);
        $query->bindParam(':continentCode', $continentCode, \PDO::PARAM_STR);
        $query->bindParam(':isProxy', $isProxy, \PDO::PARAM_BOOL);
        $query->bindParam(':zipCode', $zipCode, \PDO::PARAM_STR);
        $query->bindParam(':timeZone', $timeZone, \PDO::PARAM_STR);
    
        $query->bindParam(':browserType', $browserType, \PDO::PARAM_STR);
        $query->bindParam(':screenWidth', $screenWidth, \PDO::PARAM_STR);
        $query->bindParam(':screenHeight', $screenHeight, \PDO::PARAM_STR);
        $query->bindParam(':deviceType', $deviceType, \PDO::PARAM_STR);
        $query->bindParam(':deviceId', $deviceId, \PDO::PARAM_STR);
        $query->bindParam(':deviceReference', $deviceReference, \PDO::PARAM_STR);

        $query->execute();
    }


    public function getAmountOfSongs()
    {
          
        return "1";
    }
















 
    // 
    public function datetime($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . 'NA' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}



public function datetime_birth($datetime, $full = false) {
   $now = new DateTime;
   $ago = new DateTime($datetime);
   $diff = $now->diff($ago);

   $diff->w = floor($diff->d / 7);
   $diff->d -= $diff->w * 7;

   $string = array(
       'y' => 'year',
       'm' => 'month',
       'w' => 'week',
       'd' => 'day',
       'h' => 'hour',
       'i' => 'minute',
       's' => 'second',
   );
   foreach ($string as $k => &$v) {
       if ($diff->$k) {
           $v = $diff->$k . 'NA' . $v . ($diff->$k > 1 ? 's' : '');
       } else {
           unset($string[$k]);
       }
   }

   if (!$full) $string = array_slice($string, 0, 1);
   return $string ? implode(', ', $string) . '' : '';
}








}

?>
