<?php 
namespace Mini\Controller;

class ErrorController
{ 
     public function index()
     { // general redirection to admin dash
           require APP . 'view/error/index.php';
      }
      public function info()
      {
            require APP . 'view/error/404.php';
       }
       public function lock()
       {
             require APP . 'view/error/403.php';
        }
        public function internal()
        {
              require APP . 'view/error/500.php';
         }
        public function maintenance()
        {
              require APP . 'view/error/maintenance.php';
         }
}
