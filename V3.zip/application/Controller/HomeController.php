<?php

 

namespace Mini\Controller; 

class HomeController
{
  
    // FRONT-END
    public function index()
    {     
         require APP . 'view/_templates/client/'.VERSION.'/header.php';
        require APP . 'view/client/'.VERSION.'/index.php';
        require APP . 'view/_templates/client/'.VERSION.'/footer.php';
    }



    //  pages start
    public function terms()
    {     require APP . 'view/client/'.VERSION.'/pages/terms.php'; }
    public function privacy()
    {    require APP . 'view/client/'.VERSION.'/pages/privacy.php';  }
 //  pages end



    // authentification start
    public function authentifier()
    {     require APP . 'view/authentification/'.VERSION.'/login_v1.php';  }
    public function registre()
    {   require APP . 'view/authentification/'.VERSION.'/registre_v1.php';  }
    public function recuperation()
    {  require APP . 'view/authentification/'.VERSION.'/recuperation.php';   } 
    public function auth()
    {     require APP . 'view/authentification/'.VERSION.'/auth.php';  }
     public function verification()
     {     require APP . 'view/authentification/'.VERSION.'/verification.php';  }
      public function verify()
      {     require APP . 'view/authentification/'.VERSION.'/verify.php'; }
     public function codeverification()
     {    require APP . 'view/authentification/'.VERSION.'/codeverification.php'; }
     public function logout()
     {    require APP . 'view/authentification/'.VERSION.'/logout.php'; }
     public function trial()
     {    require APP . 'view/authentification/'.VERSION.'/trial.php'; }
    // authentification end
   
}
