<?php
 

namespace Mini\Controller;
use Mini\Model\App;

class AdministrationController
{
 
    public function ajaxGetStats()
    { 
          
         $App = new App();
         $amount_of_songs = $App->getAmountOfSongs();
  
         echo $amount_of_songs;
    }
 
        public function ajaxAction() {
            // Handle AJAX request
            $data = ['message' => 'AJAX call successful!'];
            echo json_encode($data);
        }
  



    public function index()
    {   
        require APP . 'view/_templates/admin/'.VERSION.'/header_admin.php';
        require APP . 'view/administration/'.VERSION.'/dashboard.php';
        require APP . 'view/_templates/admin/'.VERSION.'/footer_includes_admin.php';
    }
    public function settings()
    {  
         require APP . 'view/_templates/admin/'.VERSION.'/header_admin.php';
        require APP . 'view/administration/'.VERSION.'/settings/gestion.php';
        require APP . 'view/_templates/admin/'.VERSION.'/footer_includes_admin.php';
    }
    public function logs()
    {  
         require APP . 'view/_templates/admin/'.VERSION.'/header_admin.php';
        require APP . 'view/administration/'.VERSION.'/settings/logs.php';
        require APP . 'view/_templates/admin/'.VERSION.'/footer_includes_admin.php';
    }
    public function status()
    {  
        require APP . 'view/_templates/admin/'.VERSION.'/header_admin.php';
        require APP . 'view/administration/'.VERSION.'/settings/status.php';
        require APP . 'view/_templates/admin/'.VERSION.'/footer_includes_admin.php';
    }
    public function profile()
    {  
        require APP . 'view/_templates/admin/'.VERSION.'/header_admin.php';
        require APP . 'view/administration/'.VERSION.'/settings/profile.php';
        require APP . 'view/_templates/admin/'.VERSION.'/footer_includes_admin.php';
    }
}
