<?php

require APP . 'view/_templates/admin/' . VERSION . '/plugins/sys_system.php';

?>
<!doctype html> 
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>DSH   </title>
    <!-- CSS files -->
    <link href="<?php echo FILES; ?>/css/tabler.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-flags.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-payments.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-vendors.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/demo.min.css?1692870487" rel="stylesheet"/>
    <style>
      @import url('https://rsms.me/inter/inter.css');
      :root {
      	--tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
      }
      body {
      	font-feature-settings: "cv03", "cv04", "cv11";
      }
    </style>
  </head>
  <body  class=" border-top-wide border-primary d-flex flex-column">
    <script src="<?php echo FILES; ?>/js/demo-theme.min.js?1692870487"></script>
    <div class="page page-center">
      <div class="container-tight py-4">
        <div class="empty">
          <div class="empty-img"><img src="./static/illustrations/undraw_quitting_time_dm8t.svg" height="128" alt="">
          </div>
          <p class="empty-title">Temporarily down for maintenance</p>
          <p class="empty-subtitle text-secondary">
            Sorry for the inconvenience but we’re performing some maintenance at the moment. We’ll be back online shortly!
          </p>
          <div class="empty-action">
            <a href="<?php echo URL; ?>" class="btn btn-primary">
               <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l14 0" /><path d="M5 12l6 6" /><path d="M5 12l6 -6" /></svg>
               Accueil
            </a>
            <?php 
/*
  if (ENVIRONMENT == 'dev') { 
    //header("location: $home");
    $msg_reporting = "MAINTENANCE MODE DESACTIVER";
   $App->insert_loggs($table_loggs, 'VIEW',$msg_reporting,'SYSTEM',$datenow,$userid,$session_id);
 }
 */
$msg_reporting = "MAINTENANCE MODE DESACTIVER";
$App->insert_loggs($table_loggs, 'VIEW',$msg_reporting,'SYSTEM',$datenow,$userid,$session_id,URL,URI,$suburl,VERSION,$lang,$project);
            ?>
          </div>
        </div>
      </div>
    </div>
 
    <script src="<?php echo FILES; ?>/js/tabler.min.js?1692870487" defer></script>
    <script src="<?php echo FILES; ?>/js/demo.min.js?1692870487" defer></script>
  </body>
</html>