<?php

// $url_to = URL . "administration/";
$url_to = URL . "?theme=light&v=".VERSION;
header("location: $url_to");

?>