 
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>2-Step Verification - Tabler - Premium and Open Source dashboard template with responsive and high quality UI.</title>
    <!-- CSS files -->
    <link href="<?php echo FILES; ?>/css/tabler.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-flags.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-payments.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-vendors.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/demo.min.css?1692870487" rel="stylesheet"/>
    <style>
      @import url('https://rsms.me/inter/inter.css');
      :root {
      	--tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
      }
      body {
      	font-feature-settings: "cv03", "cv04", "cv11";
      }
    </style>
  </head>
  <body  class=" d-flex flex-column">
    <script src="<?php echo FILES; ?>/js/demo-theme.min.js?1692870487"></script>
    <div class="page page-center">
      <div class="container container-tight py-4">
        <div class="text-center mb-4">
          <a href="." class="navbar-brand navbar-brand-autodark">
            <img src="./static/logo.svg" width="110" height="32" alt="Tabler" class="navbar-brand-image">
          </a>
        </div>
        <form
	class="card card-md"
	action="./2-step-verification-code.html"
	method="get"
	autocomplete="off"
	novalidate
>
          <div class="card-body">
            <h2 class="card-title text-center mb-4">2-Step Verification</h2>
            <div class="mb-3">
              <label class="form-label">Country</label>
              <select class="form-select">
                <option value="">Andorra</option>
                <option value="">United Arab Emirates</option>
                <option value="">Afghanistan</option>
                <option value="">Antigua</option>
                <option value="">Anguilla</option>
                <option value="">Armenia</option>
                <option value="">Angolan</option>
                <option value="">Antarctica</option>
                <option value="">Argentina</option>
                <option value="">American Samoa</option>
                <option value="">Austria</option>
                <option value="">Australia</option>
                <option value="">Aruba</option>
                <option value="">Aslan Islands</option>
                <option value="">Azerbaijan</option>
                <option value="">Bosnian</option>
                <option value="">Barbados</option>
                <option value="">Belgium</option>
                <option value="">Burkina Faso</option>
                <option value="">Bulgaria</option>
                <option value="">Bahrain</option>
                <option value="">Burundi</option>
                <option value="">Benin</option>
                <option value="">Saint-Barthélemy</option>
                <option value="">Bermuda</option>
                <option value="">Bruneian</option>
                <option value="">Bolivia</option>
                <option value="">Bonaire</option>
                <option value="">Brazil</option>
                <option value="">Bahamas</option>
                <option value="">Bhutan</option>
                <option value="">Bouvet Island</option>
                <option value="">Batswana</option>
                <option value="">Belarus</option>
                <option value="">Belize</option>
                <option value="">Canada</option>
                <option value="">Cocos Island</option>
                <option value="">Democratic Republic of Congo</option>
                <option value="">Central African Republic</option>
                <option value="">Republic of the Congo</option>
                <option value="">Switzerland</option>
                <option value="">Ivory Coast</option>
                <option value="">Cook Island</option>
                <option value="">Chile</option>
                <option value="">Cameroon</option>
                <option value="">China</option>
                <option value="">Colombia</option>
                <option value="">Costa Rica</option>
                <option value="">Cuba</option>
                <option value="">Cape Verde</option>
                <option value="">Curacao</option>
                <option value="">Christmas Island</option>
                <option value="">Cyprus</option>
                <option value="">Czech Republic</option>
                <option value="">Germany</option>
                <option value="">Djibouti</option>
                <option value="">Denmark</option>
                <option value="">Dominica</option>
                <option value="">Dominican Republic</option>
                <option value="">Algeria</option>
                <option value="">Ecuador</option>
                <option value="">Estonia</option>
                <option value="">Egypt</option>
                <option value="">Sahrawi</option>
                <option value="">Eritrea</option>
                <option value="">Spain</option>
                <option value="">Catalonia</option>
                <option value="">Ethiopia</option>
                <option value="">European Union</option>
                <option value="">Finland</option>
                <option value="">Fiji</option>
                <option value="">Falkland Islands</option>
                <option value="">Federate States of Micronesia</option>
                <option value="">Faroe Islands</option>
                <option value="">France</option>
                <option value="">Gabon</option>
                <option value="">Great Britain</option>
                <option value="">England</option>
                <option value="">Nothern Ireland</option>
                <option value="">Scotland</option>
                <option value="">Wales</option>
                <option value="">Grenada</option>
                <option value="">Georgia</option>
                <option value="">Guyana</option>
                <option value="">Guernsey</option>
                <option value="">Ghana</option>
                <option value="">Gibraltar</option>
                <option value="">Greenland</option>
                <option value="">Gambia</option>
                <option value="">Guinea</option>
                <option value="">Guadeloupe</option>
                <option value="">Equatorial Guinea</option>
                <option value="">Greece</option>
                <option value="">South Georgia</option>
                <option value="">Guatemala</option>
                <option value="">Guam</option>
                <option value="">Guinea-Bissau</option>
                <option value="">Guyana</option>
                <option value="">Hong Kong</option>
                <option value="">Heard and McDonald Islands</option>
                <option value="">Honduras</option>
                <option value="">Croatia</option>
                <option value="">Haiti</option>
                <option value="">Hungary</option>
                <option value="">Indonesia</option>
                <option value="">Ireland</option>
                <option value="">Israel</option>
                <option value="">Isle of Man</option>
                <option value="">India</option>
                <option value="">British Indian Ocean Territory</option>
                <option value="">Iraq</option>
                <option value="">Iran</option>
                <option value="">Iceland</option>
                <option value="">Italy</option>
                <option value="">Jersey</option>
                <option value="">Jamaica</option>
                <option value="">Jordan</option>
                <option value="">Japan</option>
                <option value="">Kenya</option>
                <option value="">Kyrgyzstan</option>
                <option value="">Cambodia</option>
                <option value="">Kiribati</option>
                <option value="">Comoros</option>
                <option value="">Saint Kitts and Nevis</option>
                <option value="">North Korea</option>
                <option value="">South Korea</option>
                <option value="">Kuwait</option>
                <option value="">Cayman Islands</option>
                <option value="">Kazakhstan</option>
                <option value="">Laos</option>
                <option value="">Lebanese</option>
                <option value="">Saint Lucia</option>
                <option value="">Liechtenstein</option>
                <option value="">Sri Lanka</option>
                <option value="">Liberia</option>
                <option value="">Lesotho</option>
                <option value="">Lithuania</option>
                <option value="">Luxembourg</option>
                <option value="">Latvia</option>
                <option value="">Libya</option>
                <option value="">Morocco</option>
                <option value="">Monaco</option>
                <option value="">Moldova</option>
                <option value="">Montenegro</option>
                <option value="">Saint Martin</option>
                <option value="">Madagascar</option>
                <option value="">Marshall Islands</option>
                <option value="">Macedonia</option>
                <option value="">Mali</option>
                <option value="">Myanmar</option>
                <option value="">Mongolia</option>
                <option value="">Macao</option>
                <option value="">Nothern Mariana Islands</option>
                <option value="">Martinique</option>
                <option value="">Mauritania</option>
                <option value="">Montserrat</option>
                <option value="">Malta</option>
                <option value="">Mauritius</option>
                <option value="">Maldives</option>
                <option value="">Malawi</option>
                <option value="">Mexico</option>
                <option value="">Malaysia</option>
                <option value="">Mozambique</option>
                <option value="">Namibia</option>
                <option value="">New Caledonia</option>
                <option value="">Niger</option>
                <option value="">Norfolk Island</option>
                <option value="">Nigeria</option>
                <option value="">Nicaragua</option>
                <option value="">Norway</option>
                <option value="">Nepal</option>
                <option value="">Nauruan</option>
                <option value="">Niger</option>
                <option value="">New Zealand</option>
                <option value="">Oman</option>
                <option value="">Panama</option>
                <option value="">Peru</option>
                <option value="">French Polynesia</option>
                <option value="">Papua New Guinea</option>
                <option value="">Philippines</option>
                <option value="">Pakistan</option>
                <option value="">Poland</option>
                <option value="">Saint Pierre</option>
                <option value="">Pitcairn Islands</option>
                <option value="">Puerto Rico</option>
                <option value="">Palestine</option>
                <option value="">Portugal</option>
                <option value="">Palau</option>
                <option value="">Paraguay</option>
                <option value="">Qatar</option>
                <option value="">Reunion Island</option>
                <option value="">Romania</option>
                <option value="">Serbia</option>
                <option value="">Russia</option>
                <option value="">Rwanda</option>
                <option value="">Saudi Arabia</option>
                <option value="">Solomon Islands</option>
                <option value="">Seychelles</option>
                <option value="">Sudan</option>
                <option value="">Sweden</option>
                <option value="">Singapore</option>
                <option value="">Saint Helena</option>
                <option value="">Slovenia</option>
                <option value="">Svalbard Island</option>
                <option value="">Slovakia</option>
                <option value="">Sierra Leone</option>
                <option value="">San Marino</option>
                <option value="">Senegal</option>
                <option value="">Somalia</option>
                <option value="">Suriname</option>
                <option value="">South Sudan</option>
                <option value="">Sao Tome</option>
                <option value="">El Salvador</option>
                <option value="">Sint Maarten</option>
                <option value="">Syria</option>
                <option value="">Swaziland</option>
                <option value="">Turks and Caicos</option>
                <option value="">Chad</option>
                <option value="">French Southern and Antarctic Lands</option>
                <option value="">Togo</option>
                <option value="">Thailand</option>
                <option value="">Tajikistan</option>
                <option value="">Tokelau</option>
                <option value="">Timor Leste</option>
                <option value="">Turkmenistan</option>
                <option value="">Tunisia</option>
                <option value="">Tonga</option>
                <option value="">Turkey</option>
                <option value="">Trinidad and Tobago</option>
                <option value="">Tuvalu</option>
                <option value="">Tanzania</option>
                <option value="">Ukraine</option>
                <option value="">Uganda</option>
                <option value="">United States Minor Islands</option>
                <option value="">United Nations</option>
                <option value="">United States of America</option>
                <option value="">Uruguay</option>
                <option value="">Uzbekistan</option>
                <option value="">Vatican City</option>
                <option value="">Saint Vincent</option>
                <option value="">Venezuela</option>
                <option value="">British Virgin Islands</option>
                <option value="">Virgiin Islands</option>
                <option value="">Vietnam</option>
                <option value="">Vanuatu</option>
                <option value="">Wallis and Futuna</option>
                <option value="">Samoa</option>
                <option value="">Yemen</option>
                <option value="">South Africa</option>
                <option value="">Zambia</option>
                <option value="">Zimbabwe</option>
              </select>
            </div>
            <div class="mb-4">
              <label class="form-label">Your Phone Number</label>
              <div class="input-group">
                <span class="input-group-text">+1</span>
                <input type="text" class="form-control" placeholder="Enter phone number" />
              </div>
            </div>
            <div class="text-secondary">
              Security is critical in Tabler. to help keep your account safe, we'll
              text you a verification code when you sign in on a new device
            </div>
            <div class="form-footer">
              <button type="submit" class="btn btn-primary w-100">
                Send code
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
    <!-- Libs JS -->
    <!-- Tabler Core -->
    <script src="<?php echo FILES; ?>/js/tabler.min.js?1692870487" defer></script>
    <script src="<?php echo FILES; ?>/js/demo.min.js?1692870487" defer></script>
  </body>
</html>