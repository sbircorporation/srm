<!doctype html> 
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>Sign in link - Tabler - Premium and Open Source dashboard template with responsive and high quality UI.</title>
    <!-- CSS files -->
    <link href="<?php echo FILES; ?>/css/tabler.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-flags.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-payments.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-vendors.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/demo.min.css?1692870487" rel="stylesheet"/>
    <style>
      @import url('https://rsms.me/inter/inter.css');
      :root {
      	--tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
      }
      body {
      	font-feature-settings: "cv03", "cv04", "cv11";
      }
    </style>
  </head>
  <body  class=" d-flex flex-column">
    <script src="<?php echo FILES; ?>/js/demo-theme.min.js?1692870487"></script>
    <div class="page page-center">
      <div class="container container-tight py-4">
        <div class="text-center mb-4">
          <a href="." class="navbar-brand navbar-brand-autodark">
            <img src="./static/logo.svg" width="110" height="32" alt="Tabler" class="navbar-brand-image">
          </a>
        </div>
        <div class="text-center">
          <div class="my-5">
            <h2 class="h1">Check your inbox</h2>
            <p class="fs-h3 text-secondary">
              We've sent you a magic link to <strong>support@tabler.io</strong>.<br />
              Please click the link to confirm your address.
            </p>
          </div>
          <div class="text-center text-secondary mt-3">
            Can't see the email? Please check the spam folder.<br />
            Wrong email? Please <a href="#">re-enter your address</a>.
          </div>
        </div>
      </div>
    </div>
    <!-- Libs JS -->
    <!-- Tabler Core -->
    <script src="<?php echo FILES; ?>/js/tabler.min.js?1692870487" defer></script>
    <script src="<?php echo FILES; ?>/js/demo.min.js?1692870487" defer></script>
  </body>
</html>