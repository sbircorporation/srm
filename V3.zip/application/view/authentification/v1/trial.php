<!doctype html> 
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>Tabler - Premium and Open Source dashboard template with responsive and high quality UI.</title>
    <!-- CSS files -->
    <link href="<?php echo FILES; ?>/dist/css/tabler.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/dist/css/tabler-flags.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/dist/css/tabler-payments.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/dist/css/tabler-vendors.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/dist/css/demo.min.css?1692870487" rel="stylesheet"/>
    <style>
      @import url('https://rsms.me/inter/inter.css');
      :root {
      	--tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
      }
      body {
      	font-feature-settings: "cv03", "cv04", "cv11";
      }
    </style>
  </head>
  <body  class=" d-flex flex-column">
    <script src="<?php echo FILES; ?>/dist/js/demo-theme.min.js?1692870487"></script>
    <div class="page page-center">
      <div class="container container-tight py-4">
        <div class="text-center mb-4">
          <a href="." class="navbar-brand navbar-brand-autodark">
            <img src="./static/logo.svg" width="110" height="32" alt="Tabler" class="navbar-brand-image">
          </a>
        </div>
        <div class="card card-md">
          <div class="card-body">
            <h2 class="mb-3">Your free trial period has expired!</h2>
            <p class="text-secondary mb-4">
              If you want to continue to benefit from Tabler, it's time to upgrade your plan.
            </p>
            <ul class="list-unstyled space-y">
              <li class="row g-2">
                <span class="col-auto"><!-- Download SVG icon from http://tabler-icons.io/i/check -->
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon me-1 text-success" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>
                </span>
                <span class="col">
                  <strong class="d-block">Over 800+ productions</strong>
                  <span class="d-block text-secondary">Unlimited movies, TV shows and more.</span>
                </span>
              </li>
              <li class="row g-2">
                <span class="col-auto"><!-- Download SVG icon from http://tabler-icons.io/i/check -->
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon me-1 text-success" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>
                </span>
                <span class="col">
                  <strong class="d-block">Watch everywhere</strong>
                  <span class="d-block text-secondary">Watch on smart TVs, PlayStation, Xbox, Apple TV, Blu-ray players and more.</span>
                </span>
              </li>
              <li class="row g-2">
                <span class="col-auto"><!-- Download SVG icon from http://tabler-icons.io/i/check -->
                  <svg xmlns="http://www.w3.org/2000/svg" class="icon me-1 text-success" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>
                </span>
                <span class="col">
                  <strong class="d-block">Personalize</strong>
                  <span class="d-block text-secondary">Choose your own style, watch what you like.</span>
                </span>
              </li>
            </ul>
            <div class="my-4">
              <a href="#" class="btn btn-primary w-100">
                Upgrade to a paid plan
              </a>
            </div>
            <p class="text-secondary">
              If you need to get a trial extension please feel free to <a href="#">contact us</a>.
            </p>
          </div>
        </div>
      </div>
    </div>
    <!-- Libs JS -->
    <!-- Tabler Core -->
    <script src="<?php echo FILES; ?>/dist/js/tabler.min.js?1692870487" defer></script>
    <script src="<?php echo FILES; ?>/dist/js/demo.min.js?1692870487" defer></script>
  </body>
</html>