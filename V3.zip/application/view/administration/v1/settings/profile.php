
<div class="page">
       <?php  require APP . 'view/_templates/admin/'.VERSION.'/aside_admin.php'; ?>
       <?php  require APP . 'view/_templates/admin/'.VERSION.'/top_admin.php'; ?>
      <div class="page-wrapper"> 
         <div class="page-body">
          <div class="container-xl">
            <div class="row row-deck row-cards">
  
              <div class="col-lg-12">


              <script>
document.getElementById('ajaxButton').addEventListener('click', function() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/ajax', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            alert(response.message);
        }
    };
    xhr.send();
});
</script>
<button id="ajaxButton">Click Me</button>




             </div>
         
             </div>
           </div>
        </div>
             <?php  require APP . 'view/_templates/admin/'.VERSION.'/footer_admin.php'; ?>
      </div>
    </div>

 