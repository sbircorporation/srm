<?php

$url_to = URL . "administration/";
header("location: $url_to");

?>