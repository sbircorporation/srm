<?php 
require APP . 'view/_templates/admin/' . VERSION . '/plugins/sys_system.php';


  ?>
 


<!doctype html> 
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>DSH <?php  echo $suburl; ?> </title>
    <!-- CSS files --> 
    <link href="<?php echo FILES; ?>/css/tabler.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-flags.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/tabler-vendors.min.css?1692870487" rel="stylesheet"/>
    <link href="<?php echo FILES; ?>/css/demo.min.css?1692870487" rel="stylesheet"/>
    <style>
      @import url('https://rsms.me/inter/inter.css');
      :root {
      	--tblr-font-sans-serif: 'Inter Var', -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif;
      }
      body {
      	font-feature-settings: "cv03", "cv04", "cv11";
      }
    </style>

<?php /*if($cookie_sys == "1") { ?>
        <!-- Page body -->
        <div class="page-body">
          <div class="container-xl">
            <div class="offcanvas offcanvas-bottom h-auto show" tabindex="-1" id="offcanvasBottom" aria-modal="true" role="dialog">
              <div class="offcanvas-body">
                <div class="container">
                  <div class="row align-items-center">
                    <div class="col">
                      <strong>Do you like cookies?</strong> 🍪 We use cookies to ensure you get the best experience on our website. <a href="./terms-of-service.html" target="_blank">Learn more</a>
                    </div>
                    <div class="col-auto">
                      <button type="button" class="btn btn-primary" data-bs-dismiss="offcanvas">
                        Essential Cookies Only
                      </button>
                    </div>
                    <div class="col-auto">
                      <button type="button" class="btn btn-primary" data-bs-dismiss="offcanvas">
                        Allow All Cookies
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
<?php }*/  ?>

  </head>
  <body >
    <script src="<?php echo FILES; ?>/js/demo-theme.min.js?1692870487"></script>

 