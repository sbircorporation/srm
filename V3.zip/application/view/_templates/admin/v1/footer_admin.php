<footer class="footer footer-transparent d-print-none">
          <div class="container-xl">
            <div class="row text-center align-items-center flex-row-reverse">
              <div class="col-lg-auto ms-lg-auto">
                <ul class="list-inline list-inline-dots mb-0">

                
                <li class="list-inline-item" style="font-size:8px"><a href="https://documentation.crmsbir.com" target="_blank" class="link-secondary" rel="noopener">Documentation</a></li>
                <li class="list-inline-item" style="font-size:8px"><a href="https://documentation.crmsbir.com/changelogs/" target="_blank" class="link-secondary" rel="noopener">Changelogs</a></li>
                <li class="list-inline-item" style="font-size:8px"><a href="https://documentation.crmsbir.com/updates/" target="_blank" class="link-secondary" rel="noopener">MisAjours</a></li>
                <li class="list-inline-item" style="font-size:8px"><a href="https://erp.sbir.ma/licence/" class="link-secondary">License</a></li>
          
                 

                </ul>
              </div>
              <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item" style="font-size:8px">
                    Copyright &copy; <?php echo date('Y'); ?>
                    <!-- <a href="." class="link-secondary">Tabler</a>. -->
                    SRM SARL MARRAKECH Tous droits réservé
                  </li>
                  <li class="list-inline-item" style="font-size:8px">
                    <a href="./changelog.html" class="link-secondary" rel="noopener">
                      <?php echo VERSION; ?>-<?php echo ENVIRONMENT; ?> <a href="https://sbir.ma" target="_blank" class="link-secondary" rel="noopener">
                      SBIR.MA
                    </a>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </footer>    
        