
<?php
 
$userDetails = $App->new_session(PREFIX,$userid,$api_ipgeolocation); 

$user_ip = $_SESSION['session_details']['IP Address'] ?? 'NA';
$user_agent = $_SESSION['session_details']['User Agent'] ?? 'NA';
$php_version = $_SESSION['session_details']['PHP Info']['PHP Version'] ?? 'NA';
$server_software = $_SESSION['session_details']['PHP Info']['Server Software'] ?? 'NA';
$server_protocol = $_SESSION['session_details']['PHP Info']['Server Protocol'] ?? 'NA';
$country = $_SESSION['session_details']['Location Info']['Country'] ?? 'NA';
$region = $_SESSION['session_details']['Location Info']['Region'] ?? 'NA';
$city = $_SESSION['session_details']['Location Info']['City'] ?? 'NA';
$latitude = $_SESSION['session_details']['Location Info']['Latitude'] ?? 'NA';
$longitude = $_SESSION['session_details']['Location Info']['Longitude'] ?? 'NA';
$continent = $_SESSION['session_details']['Location Info']['Continent'] ?? 'NA';
$countryCode = $_SESSION['session_details']['Location Info']['CountryCode'] ?? 'NA';
$countryOfficial = $_SESSION['session_details']['Location Info']['CountryOfficial'] ?? 'NA';
$capital = $_SESSION['session_details']['Location Info']['Capital'] ?? 'NA';
$tlds = $_SESSION['session_details']['Location Info']['TLDs'] ?? 'NA';
$timeZones = $_SESSION['session_details']['Location Info']['TimeZones'] ?? 'NA';
$language = $_SESSION['session_details']['Location Info']['Language'] ?? 'NA';
$currencyCode = $_SESSION['session_details']['Location Info']['Currency CODE'] ?? 'NA';
$currencyName = $_SESSION['session_details']['Location Info']['Currency NAME'] ?? 'NA';
$continentCode = $_SESSION['session_details']['Location Info']['ContinentCode'] ?? 'NA';
$isProxy = $_SESSION['session_details']['Location Info']['IsProxy'] ?? 'NA';
$zipCode = $_SESSION['session_details']['Location Info']['ZipCode'] ?? 'NA';
$timeZone = $_SESSION['session_details']['Location Info']['TimeZone'] ?? 'NA';

 $browserType = $screenWidth = $screenHeight = $deviceType = $deviceId = $deviceReference = "";


function getDeviceDetails() {
    // Initialize variables
    $browserType = '';
    $screenWidth = null;
    $screenHeight = null;
    $deviceType = 'PC'; // Default to PC
    $deviceId = null;
    $deviceReference = null;

    // Detect the browser type
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    if (strpos($userAgent, 'Chrome') !== false) {
        $browserType = 'Chrome';
    } elseif (strpos($userAgent, 'Firefox') !== false) {
        $browserType = 'Firefox';
    } elseif (strpos($userAgent, 'Safari') !== false && strpos($userAgent, 'Chrome') === false) {
        $browserType = 'Safari';
    } elseif (strpos($userAgent, 'MSIE') !== false || strpos($userAgent, 'Trident') !== false) {
        $browserType = 'Internet Explorer';
    } else {
        $browserType = 'Other';
    }

    // Detect the device type
    if (preg_match('/Mobile|Android|iP(hone|od)|BlackBerry|IEMobile|Silk/', $userAgent)) {
        $deviceType = 'Phone';
    } elseif (preg_match('/Tablet|iPad|PlayBook|Kindle/', $userAgent)) {
        $deviceType = 'Tablet';
    }

    // Extract additional device details for phones and tablets
    if ($deviceType === 'Phone' || $deviceType === 'Tablet') {
        if (preg_match('/\(([^;]+);/', $userAgent, $matches)) {
            $deviceId = trim($matches[1]);
        }
        $deviceReference = $userAgent;
    }

    // Retrieve screen width and height using JavaScript injection (requires client-side support)
    echo "
        <script>
            document.cookie = 'screen_width=' + screen.width + '; path=/';
            document.cookie = 'screen_height=' + screen.height + '; path=/';
        </script>
    ";

    // Fetch screen dimensions from cookies if available
    if (isset($_COOKIE['screen_width'])) {
        $screenWidth = $_COOKIE['screen_width'];
    }
    if (isset($_COOKIE['screen_height'])) {
        $screenHeight = $_COOKIE['screen_height'];
    }

    // Return individual variables
    return [
        'browserType' => $browserType,
        'screenWidth' => $screenWidth,
        'screenHeight' => $screenHeight,
        'deviceType' => $deviceType,
        'deviceId' => $deviceId,
        'deviceReference' => $deviceReference,
    ];
} 
$details = getDeviceDetails();  

$browserType = $details['browserType'];
$screenWidth = $details['screenWidth'];
$screenHeight = $details['screenHeight'];
$deviceType = $details['deviceType'];
$deviceId = $details['deviceId'];
$deviceReference = $details['deviceReference'];


 

$userDetails = $App->add_active_session(PREFIX,URL,URI,VERSION,$userid,$datenow,$user_ip,$user_agent,$php_version,$server_software,$server_protocol,$country,$region,$city,$longitude,$latitude,$continent,$countryCode,$countryOfficial,$capital,$tlds,$timeZones,$language,$currencyCode,$currencyName,$continentCode,$isProxy,$zipCode,$timeZone,$browserType,$screenWidth,$screenHeight,$deviceType,$deviceId,$deviceReference);


?>

