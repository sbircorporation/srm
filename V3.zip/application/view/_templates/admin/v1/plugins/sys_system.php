<?php

use Mini\Model\App;
$App = new App();
if (session_status() == PHP_SESSION_NONE) { 
    session_start();
    ob_start();
}


$format_date = 'd/m/Y H:i:s';
$datenow = date($format_date);
$table_loggs = PREFIX . "loggs";
$userid = $session_id = $message_log = $case_session = $case_loggs = $lang = $project = $api_ipgeolocation = $case_ipgeolocation = $case_ipapi = $case_ipinfo = "";
$page_maintenance = MAINTENANCE; $page_404 = P404; $page_403 = P403; $page_405 = P405; $home = HOME;$string = QUERY_STRING; $suburl = substr($string,4);

 
GLOBAL $thisdb;
$table = PREFIX . "system";
 $db_query = $thisdb->prepare("SELECT * FROM {$table} WHERE id = :id  ");
 $prm_db = array(':id'=>UID);
 $db_query->execute($prm_db);
$count_db_query = $db_query->rowCount();
if($count_db_query > 0 ) {
    $apps = $db_query->fetchAll(PDO::FETCH_ASSOC);
    foreach ($apps as $row => $val) {
        $cookie_sys = $App->html($val['cookie']); 
        $case_ipgeolocation = $App->html($val['case_ipgeolocation']); $api_ipgeolocation = $App->html($val['ipgeolocation']);  
        $format_date = $val['format_date'];  $datenow = date($format_date);

        $case_session_action = $App->html($val['case_session_action']);
        if($case_session_action == '' || $case_session_action == 'Normal') {
            $case_session = $App->html($val['case_session']);  if ($case_session == 1) { require APP . 'view/_templates/admin/' . VERSION . '/plugins/sessions.php'; }
        } else {
          // ajax session start

          // ajax session end
        }
       
        $case_loggs_action = $App->html($val['case_loggs_action']);
        if($case_session_action == '' || $case_session_action == 'Normal') {
            $case_loggs = $App->html($val['case_loggs']);  if ($case_loggs == 1) { require APP . 'view/_templates/admin/' . VERSION . '/plugins/loggs.php'; }
          } else {
            // ajax loggs start
  
            // ajax loggs end
          } 
    }
  } else {
       try {
        $apps = $App->get_config('system', 'id', UID, PREFIX, $datenow,URL,URI,$suburl,VERSION,$lang,$project); 
       } catch (Exception $e) {
        $message_log = 'Error: ' . $e->getMessage();
          error_log($message_log);
          $App->insert_loggs($table_loggs, 'VIEW',$message_log,'SYSTEM',$datenow,$userid,$session_id,URL,URI,$suburl,VERSION,$lang,$project);
      } 
  }


  if($suburl != "error/maintenance/") {
    if (ENVIRONMENT == 'beta') {
       header("location: $page_maintenance");
       $msg_reporting = "MAINTENANCE MODE ACTIVE";
      $App->insert_loggs($table_loggs, 'VIEW',$msg_reporting,'SYSTEM',$datenow,$userid,$session_id,URL,URI,$suburl,VERSION,$lang,$project);
    }
  }
    

  if (ENVIRONMENT == 'dev_pro') {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    $msg_reporting = error_reporting(E_ALL) . " " . ini_set("display_errors", 1);
    $App->insert_loggs($table_loggs, 'VIEW',$msg_reporting,'SYSTEM',$datenow,$userid,$session_id,URL,URI,$suburl,VERSION,$lang,$project);
}




  ?>