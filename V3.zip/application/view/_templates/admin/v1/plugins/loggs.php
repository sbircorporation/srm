<?php
//$App->insert_loggs($table_loggs, 'VIEW',$message_log,'',$datenow,$userid,$session_id);
GLOBAL $thisdb;
$uniqueId = $App->generateUniqueId($table_loggs); $action_log = "VIEW"; $type_logg = "GENERAL";
$sql = "INSERT INTO {$table_loggs} (id, deleted, status, action, message, type,created_at, modified_at, userid, sessionid,url,uri,suburl,version,lang,project) 
VALUES (:id, '0', '1', :action, :message, :type_logg, :date, :date, :user, :session_id,:url,:uri,:suburl,:version,:lang,:project)";
$query = $thisdb->prepare($sql);
$query->bindParam(':id', $uniqueId, \PDO::PARAM_STR);
$query->bindParam(':action', $action_log, \PDO::PARAM_STR);
$query->bindParam(':message', $message_log, \PDO::PARAM_STR);
$query->bindParam(':type_logg', $type_logg, \PDO::PARAM_STR);
$query->bindParam(':date', $datenow, \PDO::PARAM_STR);
$query->bindParam(':user', $userid, \PDO::PARAM_STR);
$query->bindParam(':session_id', $session_id, \PDO::PARAM_STR);

$query->bindParam(':url', $url, \PDO::PARAM_STR);
$query->bindParam(':uri', $uri, \PDO::PARAM_STR);
$query->bindParam(':suburl', $suburl, \PDO::PARAM_STR);
$query->bindParam(':version', $version, \PDO::PARAM_STR);
$query->bindParam(':lang', $lang, \PDO::PARAM_STR);
$query->bindParam(':project', $project, \PDO::PARAM_STR);

$query->execute();




?>