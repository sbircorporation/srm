<header class="navbar navbar-expand-md d-none d-lg-flex d-print-none" >
        <div class="container-xl">
      

          <div class="navbar-nav flex-row order-md-last">
            <div class="d-none d-md-flex"> 

        <a href="?theme=<?php 
        if(isset($_GET['theme'])) {
          $theme_actuel = $_GET['theme'];
          if($theme_actuel == "light") {   
            ?>dark" class="nav-link px-0 hide-theme-dark" title="Enable dark mode" data-bs-toggle="tooltip" <?php
          } else {
            ?>light" class="nav-link px-0 hide-theme-light" title="Enable light mode" data-bs-toggle="tooltip" <?php
          }
        }  else {
          ?>light" class="nav-link px-0 hide-theme-light" title="Enable light mode" data-bs-toggle="tooltip" <?php
        }
        ?> data-bs-placement="bottom">
        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z" /></svg>
        </a>
 

              <?php  require APP . 'view/_templates/admin/'.VERSION.'/notifications.php'; ?>


              </div>
              </div>
            </div>





            <div class="nav-item dropdown">
              <a href="javascript:void" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown" aria-label="Open user menu">
                <span class="avatar avatar-sm" style="background-image: url(<?php echo FILES; ?>/static/avatars/000m.jpg)"></span>
                <div class="d-none d-xl-block ps-2">
                  <div>Paweł Kuna</div>
                  <div class="mt-1 small text-secondary">UI Designer</div>
                </div>
              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
              <a href="<?php echo URL; ?>administration/status/" class="dropdown-item">Status</a>
                 <a href="<?php echo URL; ?>administration/logs/" class="dropdown-item">Logs</a>
                 <!-- <div class="dropdown-divider"></div> -->
                 <a href="<?php echo URL; ?>administration/profile/" class="dropdown-item">Profile</a>
                 <a href="<?php echo URL; ?>administration/settings/" class="dropdown-item">Settings</a>
                 <a href="<?php echo URL; ?>logout/" class="dropdown-item">Logout</a>
              </div>
            </div>
          </div>
          <div class="collapse navbar-collapse" id="navbar-menu">
            <div>
              
            <?php /*
              <form action="./" method="get" autocomplete="off" novalidate>
                <div class="input-icon">
                  <span class="input-icon-addon">
                    <!-- Download SVG icon from http://tabler-icons.io/i/search -->
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" /><path d="M21 21l-6 -6" /></svg>
                  </span>
                  <input type="text" value="" class="form-control" placeholder="Search…" aria-label="Search in website">
                </div>
              </form> 
              */ ?>

            </div>
          </div>
        </div>
      </header>