
     <!-- -->
    <script src="<?php echo FILES; ?>/js/demo.min.js?1692870487" defer></script>

 

    <script src="<?php echo FILES; ?>/js/tabler.min.js?1692870487" defer></script>

    <script src="//code.jquery.com/jquery-3.6.1.min.js"></script>

 
<script>
    var url = "<?php echo URL; ?>"; 
</script>

<!-- our JavaScript -->
<script src="<?php echo URL; ?>js/application.js"></script>


  </body>
</html>



