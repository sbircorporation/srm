<?php

 
define('ENVIRONMENT', 'dev'); 
// dev_pro :  running + bugs
// dev     :  normal
// beta    :  maintenance
 
define('URL_PUBLIC_FOLDER', 'public');
define('URL_PROTOCOL', '//');
define('URL_DOMAIN', $_SERVER['HTTP_HOST']);
define('REQUEST_URI', $_SERVER['REQUEST_URI']);
define('QUERY_STRING', $_SERVER['QUERY_STRING']);  
define('URL_SUB_FOLDER', str_replace(URL_PUBLIC_FOLDER, '', dirname($_SERVER['SCRIPT_NAME'])));
define('URL', URL_PROTOCOL . URL_DOMAIN . URL_SUB_FOLDER);
define('URI', REQUEST_URI);
define('VERSION', 'v1');                        // Version v1 v2 v3
$url_doc = URL . "assets/" . VERSION . "/";      
define('FILES', $url_doc);                      
$file_upload_directory = URL . "uploads/"; 
define('UPLOADS', $file_upload_directory);        

/**
 * Configuration for: Database
 * This is the place where you define your database credentials, database type etc.
 */
define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'srm');            // VERIFIER BASE DE DONNEE SUR PHPMYADMIN
define('DB_USER', 'root');           // NOM UTILISATEUR
define('DB_PASS', '');               // MOT DE PASSE
define('DB_CHARSET', 'utf8');

$thisdb = new PDO(DB_TYPE . ':host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET, DB_USER, DB_PASS);

define('PREFIX', 'sbir_');           // NE PAS CHANGER
define('UID', '668f1b33033f5d9c6');  // NE PAS CHANGER


$url_home = URL; define('HOME', $url_home);
$url_maintenance = URL . "error/maintenance/"; define('MAINTENANCE', $url_maintenance);
$url_403 = URL . "error/403/"; define('P403', $url_403);
$url_404 = URL . "error/404/"; define('P404', $url_404);
$url_405 = URL . "error/405/"; define('P405', $url_405);

 
